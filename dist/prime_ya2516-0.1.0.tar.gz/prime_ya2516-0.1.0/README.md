# prime_ya2516

python package for determining prime numbers

## Installation

```bash
$ pip install prime_ya2516
```

## Usage

- TODO

## Contributing

Interested in contributing? Check out the contributing guidelines. Please note that this project is released with a Code of Conduct. By contributing to this project, you agree to abide by its terms.

## License

`prime_ya2516` was created by Yuchen An. It is licensed under the terms of the MIT license.

## Credits

`prime_ya2516` was created with [`cookiecutter`](https://cookiecutter.readthedocs.io/en/latest/) and the `py-pkgs-cookiecutter` [template](https://github.com/py-pkgs/py-pkgs-cookiecutter).
